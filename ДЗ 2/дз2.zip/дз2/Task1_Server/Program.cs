using System.Net;
using System.Net.Sockets;
using System.Text;

class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new MainForm());
    }
}

class MainForm : Form
{
    TextBox log = new TextBox { Multiline = true, ReadOnly = true, Dock = DockStyle.Fill, ScrollBars = ScrollBars.Vertical };
    FlowLayoutPanel panel = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 50 };
    public MainForm()
    {
        Text = "Task1_Server"; Width = 650; Height = 350;
        Controls.Add(log); Controls.Add(panel);
        AddButton("Запустить сервер", "");
    }
    void AddButton(string title, string request)
    {
        Button button = new Button { Text = title, AutoSize = true };
        panel.Controls.Add(button);
        button.Click += async (s, e) =>
        {
            panel.Enabled = false;
            try { await Task.Run(() => Run(request)); }
            catch (Exception ex) { Log("Ошибка: " + ex.Message); }
            finally { panel.Enabled = true; }
        };
    }
    void Log(string text)
    {
        if (InvokeRequired) { Invoke(new Action(() => Log(text))); return; }
        log.AppendText(text + Environment.NewLine);
    }
    void Run(string unused)
    {
        TcpListener listener = new TcpListener(IPAddress.Loopback, 5000);
            listener.Start();
            try
            {
                Log("Сервер запущен. Ожидание клиента...");
                using TcpClient client = listener.AcceptTcpClient();
                using NetworkStream stream = client.GetStream();
                using StreamReader reader = new StreamReader(stream, Encoding.UTF8);
                using StreamWriter writer = new StreamWriter(stream, new UTF8Encoding(false)) { AutoFlush = true };
                string request = reader.ReadLine() ?? "";
                string ip = ((IPEndPoint)client.Client.RemoteEndPoint!).Address.ToString();
                Log($"В {DateTime.Now:HH:mm} от {ip} получена строка: {request}");
                string response = "Привет, клиент!";
                writer.WriteLine(response);
                Log("Отправлено: " + response);
            }
            finally { listener.Stop(); }
    }
}
