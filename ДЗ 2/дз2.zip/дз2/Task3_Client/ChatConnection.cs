using System.Net;
using System.Net.Sockets;
using System.Text;

// Сетевой класс не зависит от оконного интерфейса.
class ChatConnection : IDisposable
{
    TcpClient client;
    StreamReader reader;
    StreamWriter writer;
    SemaphoreSlim gate = new SemaphoreSlim(1);
    public ChatConnection(TcpClient client)
    {
        this.client = client;
        NetworkStream stream = client.GetStream();
        reader = new StreamReader(stream, Encoding.UTF8);
        writer = new StreamWriter(stream, new UTF8Encoding(false)) { AutoFlush = true };
    }
    public static async Task<ChatConnection> Accept(string ip, int port)
    {
        TcpListener server = new TcpListener(IPAddress.Parse(ip), port);
        server.Start();
        try { return new ChatConnection(await server.AcceptTcpClientAsync()); }
        finally { server.Stop(); }
    }
    public static async Task<ChatConnection> Connect(string ip, int port)
    {
        TcpClient client = new TcpClient();
        try { await client.ConnectAsync(ip, port); return new ChatConnection(client); }
        catch { client.Close(); throw; }
    }
    public Task<string?> Read() => reader.ReadLineAsync();
    public async Task Send(string text)
    {
        await gate.WaitAsync();
        try { await writer.WriteLineAsync(text); }
        finally { gate.Release(); }
    }
    public void Dispose() { client.Close(); }
}
