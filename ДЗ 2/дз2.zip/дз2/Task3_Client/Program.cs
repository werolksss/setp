using System.Net;
using System.Net.Sockets;
using System.Text;

class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new MainForm());
    }
}

class MainForm : Form
{
    const bool IsServer = false;
    TextBox ip = new TextBox { Text = "127.0.0.1", Width = 110 };
    TextBox port = new TextBox { Text = "5002", Width = 60 };
    CheckBox computer = new CheckBox { Text = "Компьютер", AutoSize = true };
    Button connect = new Button { Text = "Подсоединиться", AutoSize = true };
    TextBox log = new TextBox { Multiline = true, ReadOnly = true, Dock = DockStyle.Fill, ScrollBars = ScrollBars.Vertical };
    TextBox message = new TextBox { Width = 360 };
    Button send = new Button { Text = "Отправить", Enabled = false, AutoSize = true };
    Button bye = new Button { Text = "Bye", Enabled = false };
    ChatConnection? chat;
    string[] phrases = { "Привет!", "Как дела?", "Всё хорошо.", "Расскажи что-нибудь.", "Интересно!", "До встречи!" };
    public MainForm()
    {
        Text = IsServer ? "Чат — сервер" : "Чат — клиент";
        Width = 760; Height = 440;
        FlowLayoutPanel top = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 45 };
        top.Controls.AddRange(new Control[] { new Label { Text = "IP", AutoSize = true }, ip, new Label { Text = "Порт", AutoSize = true }, port, computer, connect });
        FlowLayoutPanel bottom = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 45 };
        bottom.Controls.AddRange(new Control[] { message, send, bye });
        Controls.Add(log); Controls.Add(bottom); Controls.Add(top);
        connect.Click += async (s, e) => await Connect();
        send.Click += async (s, e) => { string text = message.Text; message.Clear(); await Send(text); };
        bye.Click += async (s, e) => await Send("Bye");
        FormClosed += (s, e) => chat?.Dispose();
    }
    void Log(string text) => log.AppendText(text + Environment.NewLine);
    async Task Connect()
    {
        connect.Enabled = false; computer.Enabled = false;
        ChatConnection? session = null;
        try
        {
            int number = int.Parse(port.Text);
            Log(IsServer ? "Ожидание клиента..." : "Подключение...");
            session = IsServer ? await ChatConnection.Accept(ip.Text, number) : await ChatConnection.Connect(ip.Text, number);
            chat = session;
            Log("Соединение установлено.");
            send.Enabled = !computer.Checked; bye.Enabled = true;
            if (computer.Checked && !IsServer) await Send(phrases[Random.Shared.Next(phrases.Length)]);
            int replies = 0;
            while (chat == session)
            {
                string? text = await session.Read();
                if (text == null) break;
                Log("Собеседник: " + text);
                if (text == "Bye") break;
                if (computer.Checked)
                {
                    await Task.Delay(700);
                    if (chat != session) break;
                    replies++;
                    await Send(replies >= 10 ? "Bye" : phrases[Random.Shared.Next(phrases.Length)]);
                }
            }
        }
        catch (Exception ex) { if (session == null || chat == session) Log("Ошибка: " + ex.Message); }
        finally
        {
            session?.Dispose(); chat = null;
            send.Enabled = false; bye.Enabled = false;
            connect.Enabled = true; computer.Enabled = true;
            Log("Соединение закрыто.");
        }
    }
    async Task Send(string text)
    {
        ChatConnection? session = chat;
        if (session == null || string.IsNullOrWhiteSpace(text)) return;
        try
        {
            await session.Send(text);
            Log("Я: " + text);
            if (text == "Bye") { chat = null; session.Dispose(); send.Enabled = false; bye.Enabled = false; }
        }
        catch (Exception ex) { Log("Ошибка: " + ex.Message); session.Dispose(); }
    }
}
